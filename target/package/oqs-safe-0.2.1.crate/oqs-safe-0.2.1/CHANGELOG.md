# Changelog

## 0.1.0
- Initial release: Kyber768 (ML-KEM-768) and Dilithium2 (ML-DSA-44) via liboqs, with mock fallback.
- Generic factory + legacy name fallbacks.
- Safe accessors; zeroize on secrets; examples; CI.
