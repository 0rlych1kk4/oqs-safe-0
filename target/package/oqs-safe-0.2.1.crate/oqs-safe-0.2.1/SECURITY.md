# Security Policy

If you believe you have found a security vulnerability, please email <orlychikka@gmail.com>.
Do **not** open a public issue.

Supported versions: latest published crate and `main`.
We aim to respond within 7 days.
